﻿namespace XmlFormattingAssignmentTest.TestCase1
{
    public class Session
    {
        public int DurationInHour { get; set; }
        public string? LearningObjective { get; set; }

    }
}
