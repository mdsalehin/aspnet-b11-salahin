﻿namespace XmlFormattingAssignmentTest.TestCase1
{
    public class Phone
    {
        public string? Number { get; set; }
        public string? Extension { get; set; }
        public string? CountryCode { get; set; }
    }
}
