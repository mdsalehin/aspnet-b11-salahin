﻿namespace XmlFormattingAssignmentTest.TestCase1
{
    public class AdmissionTest
    {
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public double TestFees { get; set; }

    }
}
